package com.example.Shoppingmall_Shopowner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
// postman->controller->service->repository->database

import com.example.Shoppingmall_Shopowner.entity.Shopowner_entity;
import com.example.Shoppingmall_Shopowner.service.Shopowner_service;

@RestController
public class Shopowner_controller {
	@Autowired
	public Shopowner_service ss;
	@PostMapping("/add") //save
	public Shopowner_entity registershopowner(@RequestBody Shopowner_entity s) {
		return ss.registershopowner(s);
		
	}
	@GetMapping("/getshopowners")//get
	public List<Shopowner_entity> getshopowners() {
		return ss.getshopowners();
	}
	
	
	@DeleteMapping("/deleteshopowner/{id}")//delete
	public void deleteshopowner(@PathVariable("id") Long id) {
	    ss.deleteshopowner(id);
	}

}
