package com.example.Shoppingmall_Shopowner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Shoppingmall_Shopowner.entity.Shopowner_entity;
import com.example.Shoppingmall_Shopowner.repository.Shopowner_repo;

@Service

public class Shopowner_service {
	
	@Autowired
	private Shopowner_repo sr;
	
	//create
	
	public Shopowner_entity registershopowner (Shopowner_entity s) {
		return sr.save(s);
	}
	
	// read 
	
	public List<Shopowner_entity> getshopowners() {
		return (List<Shopowner_entity>) sr.findAll();
	}
	
	
	// delete
	
	public void deleteshopowner(Long id) {
		sr.deleteById(id);
	}

}
