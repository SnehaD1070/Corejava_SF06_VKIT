package com.example.Shoppingmall_Shopowner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingmallShopownerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingmallShopownerApplication.class, args);
	}

}
