package com.example.Shoppingmall_Shopowner.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Shoppingmall_Shopowner.entity.Shopowner_entity;

@Repository
public interface Shopowner_repo extends JpaRepository<Shopowner_entity , Long>{
	

}
