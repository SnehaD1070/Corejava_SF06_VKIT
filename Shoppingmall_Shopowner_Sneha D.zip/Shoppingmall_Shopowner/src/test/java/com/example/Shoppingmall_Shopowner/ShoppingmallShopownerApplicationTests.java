package com.example.Shoppingmall_Shopowner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallShopownerApplicationTests {

	@Test
	void contextLoads() {
	}

}
